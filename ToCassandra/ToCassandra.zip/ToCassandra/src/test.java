
public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		

		String test = "12312-123-12-1213";
		
		
		
		System.out.println(test.split("\\ ").length);
		

	}

}
